/**HEADER********************************************************************
*
* Copyright (c) 2013 Freescale Semiconductor;
* All Rights Reserved
*
***************************************************************************
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
* THE POSSIBILITY OF SUCH DAMAGE.
*
**************************************************************************
*
* $FileName: i2c_auto.c$
* $Version : $
* $Date    : Nov-15-2013$
* $Updated : Sep-4-2014$
* $Updated : May-20-2015$
* Comments:
*
*   This file contains the source for a example of peripheral communication by hcasf.
*
*
*END************************************************************************/
#include <mqx.h>
#include <bsp.h>
#include <message.h>
#include "i2c_auto.h"
#include "mqx_auxiliary_types.h"
#include "hcasf_command_type.h"
#include "fsl_i2c_master_driver.h"
#include "fsl_i2c_slave_driver.h"
#include "pin_mux.h"

void dataReset(uint8_t *, uint32_t);
bool i2cCompare(uint8_t *, uint8_t *, uint8_t);
void i2cBuffFree(uint8_t *, uint8_t *);
bool i2cRtosLedStatePrint(uint8_t *, uint8_t *);

static bool i2c_initialized[I2C_INSTANCE_COUNT] = {false};
static uint16_t i2c_addrs[I2C_INSTANCE_COUNT] = {0};
static uint32_t i2c_bdrs[I2C_INSTANCE_COUNT] = {0};

enum _subaddress_index_e
{
    Subaddress_Index_0 = 0x00,
    Subaddress_Index_1 = 0x01,
    Subaddress_Index_2 = 0x02,
    Subaddress_Index_3 = 0x03,
    Subaddress_Index_4 = 0x04,
    Subaddress_Index_5 = 0x05,
    Subaddress_Index_6 = 0x06,
    Subaddress_Index_7 = 0x07,
    Invalid_Subaddress_Index,
    Max_Subaddress_Index
};

#if defined(FSL_RTOS_MQX)
extern void MQX_I2C0_IRQHandler(void);
extern void MQX_I2C1_IRQHandler(void);
#endif
/*FUNCTION****************************************************************
*
* Function Name    : i2cInitFunc
* Returned Value   : false/ true
* Comments         :
*    This function is supposed to initialize I2C device
*    In fact, we use flag g_i2cStatePtr[i2c_instance] to indicate the i2c initial status.
*END*********************************************************************/
bool i2cInitFunc(uint32_t argc, uint8_t* argv[])
{
    if (2 > argc || NULL == argv[0] || NULL == argv[1])
    {
        return false;
    }

    uint8_t i2c_instance = *argv[0] - '0';

    if (i2c_instance >= I2C_INSTANCE_COUNT)
      return false;

    if (0 == strcmp((char const *)argv[1], "ON"))
    {
      if (i2c_initialized[i2c_instance]) // already initialized
        return false;
      i2c_initialized[i2c_instance] = true;

      OSA_Init();
      /* Set i2c int priority*/
      NVIC_SetPriority(I2C0_IRQn, 6U);
      OSA_InstallIntHandler(I2C0_IRQn, MQX_I2C0_IRQHandler);
      OSA_Start();

      configure_i2c_pins(i2c_instance);
    }
    else if (0 == strcmp((char const *)argv[1], "OFF"))
    {
      if (!i2c_initialized[i2c_instance])
        return false;
      deconfigure_i2c_pins(i2c_instance);
      i2c_initialized[i2c_instance] = false;
    }
    else
    {
        return false;
    }
    return true;
}

bool i2cSetBaudrate(uint32_t argc, uint8_t* argv[])
{
    uint32_t bdr = 0;

    if (2 > argc || NULL == argv[0] || NULL == argv[1])
    {
      return false;
    }

    uint8_t i2c_instance = *argv[0] - '0';

    if (i2c_instance >= I2C_INSTANCE_COUNT)
      return false;
    if (!i2c_initialized[i2c_instance]) // not initialized
      return false;

    bdr = hcasf_string2uint32(argv[1]);

    i2c_bdrs[i2c_instance] = bdr/1000; // we use kbps as unit

    return true;
}

bool i2cSetAddress(uint32_t argc, uint8_t* argv[])
{
    uint16_t addr = 0;

    if (2 > argc || NULL == argv[0] || NULL == argv[1])
    {
      return false;
    }

    uint8_t i2c_instance = *argv[0] - '0';

    if (i2c_instance >= I2C_INSTANCE_COUNT)
      return false;
    if (!i2c_initialized[i2c_instance]) // not initialized
      return false;

    addr = hcasf_string2uint32(argv[1]);

    i2c_addrs[i2c_instance] = addr;

    return true;
}

bool i2cActEntry(uint32_t argc, uint8_t* argv[])
{
    bool result = false;

    if (2 > argc || NULL == argv[0] || NULL == argv[1])
    {
      return false;
    }

    uint8_t i2c_instance = *argv[0] - '0';

    if (i2c_instance >= I2C_INSTANCE_COUNT)
      return false;
    if (!i2c_initialized[i2c_instance]) // not initialized
      return false;

    if (strcmp((char const *)argv[1],"KSDK_B2B_MASTER") == 0)
    {
      result = i2cActAsMasterForB2B(i2c_instance);
      return result;
    }
    else if (strcmp((char const *)argv[1],"KSDK_B2B_SLAVE") == 0)
    {
      result = i2cActAsSlaveForB2B(i2c_instance);
      return result;
    }
    else if (strcmp((char const *)argv[1],"HEXIWEAR") == 0)
    {
      result = i2cActAsSlaveForHEXI(i2c_instance);
      return result;
    }


    /*!!! Not use in SDK 2.0 !!!*/

   else if (strcmp((char const *)argv[1],"KSDK_EX_RECV") == 0)
   {
     result = i2cActAsSlaveForEx(i2c_instance);
     return result;
   }
   else if (strcmp((char const *)argv[1],"KSDK_EX_SEND") == 0)
   {
     result = i2cActAsMasterForEx(i2c_instance);
     return result;
   }
   else if (strcmp((char const *)argv[1],"KSDK_EX_POLLING_SEND") == 0)
   {
     result = i2cActAsMasterForExPolling(i2c_instance);
     return result;
   }
   else if (strcmp((char const *)argv[1],"KSDK_RTOS_RECV") == 0)
   {
     result = i2cActAsSlaveForI2CRtos(i2c_instance);
     return result;
   }
   else if (strcmp((char const *)argv[1],"KSDK_RTOS_SEND") == 0)
   {
     result = i2cActAsMasterForI2CRtos(i2c_instance);
     return result;
   }
   else if (strcmp((char const *)argv[1],"KSDK_COMM_SEND") == 0)
   {
       result = i2cActAsMasterForI2CComm(i2c_instance);
       return result;
   }
   else if (strcmp((char const *)argv[1],"KSDK_COMM_RECV") == 0)
   {
       result = i2cActAsSlaveForI2CComm(i2c_instance);
       return result;
   }
    else
    {
      return false;
    }
}





/*TASK*-------------------------------------------------------------------
*
* Task Name : i2cActAsMasterForB2B
* Comments  :
*        Assist case for i2c example b2b slave
*END*----------------------------------------------------------------------*/
bool i2cActAsMasterForB2B(uint8_t i2c_instance)
{
    i2c_status_t i2c_user_status = kStatus_I2C_Success;
    bool result = true;
    uint8_t *sendDataPtr = NULL;
    uint8_t *recvDataPtr = NULL;
    i2c_master_state_t master;

    i2c_device_t device =
    {
        .address = i2c_addrs[i2c_instance],
        .baudRate_kbps = i2c_bdrs[i2c_instance]   // Kbps
    };
    I2C_DRV_MasterInit(i2c_instance, &master);
    // data section
    sendDataPtr = (uint8_t *)_mem_alloc(I2C_EX_B2B_NUM * sizeof(uint8_t));
    recvDataPtr = (uint8_t *)_mem_alloc(I2C_EX_B2B_NUM * sizeof(uint8_t));
    // set data to 0, 1, 2, ..., I2C_EX_B2B_NUM
    dataReset(sendDataPtr, I2C_EX_B2B_NUM);

    OSA_TimeDelay(25);
    I2C_DRV_MasterSendDataBlocking(i2c_instance, &device,
                                   NULL,0,
                                   (const uint8_t*)sendDataPtr, I2C_EX_B2B_NUM,
                                   1000);

    // Delay to wait slave received data
    OSA_TimeDelay(25);
    // Clear receive data setion
    memset(recvDataPtr, 0, I2C_EX_B2B_NUM * sizeof(uint8_t));

    I2C_DRV_MasterReceiveDataBlocking(i2c_instance, &device,
                                      NULL, 0,
                                      recvDataPtr, I2C_EX_B2B_NUM,
                                      10000);
    OSA_TimeDelay(25);
    if (i2cCompare(sendDataPtr, recvDataPtr, I2C_EX_B2B_NUM) == false)
    {
        result = false;
        i2cBuffFree(sendDataPtr, recvDataPtr);
    }

    if (result == false)
    {
        kprintf("MASTER send and receive failed!\n");
    }
    else
    {
        kprintf("MASTER send and receive OK!\n");
    }

    i2cBuffFree(sendDataPtr, recvDataPtr);

    I2C_DRV_MasterDeinit(i2c_instance);

    return result;
}

/*TASK*-------------------------------------------------------------------
*
* Task Name : i2cActAsSlaveForB2B
* Comments  :
*        Assist case for i2c example b2b master
*END*----------------------------------------------------------------------*/
bool i2cActAsSlaveForB2B(uint8_t i2c_instance)
{
    i2c_status_t i2c_user_status = kStatus_I2C_Success;
    bool result = 0;
    uint8_t *dataPtr = NULL;
    i2c_slave_state_t slave;
    i2c_slave_user_config_t userConfig =
    {
        .address        = i2c_addrs[i2c_instance],
        .slaveCallback  = NULL,
        .callbackParam  = NULL,
        .slaveListening = false,
#if FSL_FEATURE_I2C_HAS_START_STOP_DETECT
        .startStopDetect  = false,
#endif
#if FSL_FEATURE_I2C_HAS_STOP_DETECT
        .stopDetect       = false,
#endif
    };

    // Initialize slave
    I2C_DRV_SlaveInit(i2c_instance, &userConfig, &slave);

    dataPtr = (uint8_t *)_mem_alloc(I2C_EX_B2B_NUM * sizeof(uint8_t));

    memset(dataPtr, 0, I2C_EX_B2B_NUM * sizeof(uint8_t));

    // Slave receive buffer from master
    I2C_DRV_SlaveReceiveDataBlocking(i2c_instance, dataPtr, I2C_EX_B2B_NUM, 10000);

    // Slave send buffer received from master
    i2c_user_status = I2C_DRV_SlaveSendDataBlocking(i2c_instance, dataPtr, I2C_EX_B2B_NUM, 10000);
    if (i2c_user_status == kStatus_I2C_Success)
    {
        result = true;
    }

    /* Print the slave received data */
    kprintf("I2C SLAVE RECEIVED DATA:\n");

    for (uint8_t i = 0; i < I2C_EX_B2B_NUM; i++)
    {
        kprintf("0x%x ", dataPtr[i]);
    }

    _mem_free(dataPtr);

    dataPtr = NULL;

    I2C_DRV_SlaveDeinit(i2c_instance);

    return result;
}

/*TASK*-------------------------------------------------------------------
*
* Task Name : i2cActAsSlaveForHEXI
* Comments  :
*        Assist case for HEXIWEAR irthermo case.
*END*----------------------------------------------------------------------*/
bool i2cActAsSlaveForHEXI(uint8_t i2c_instance)
{
    i2c_status_t i2c_user_status = kStatus_I2C_Success;
    bool result = 0;
    uint8_t receData ;
    uint8_t sendData[2];
    i2c_slave_state_t slave;
    i2c_slave_user_config_t userConfig =
    {
        .address        = i2c_addrs[i2c_instance],
        .slaveCallback  = NULL,
        .callbackParam  = NULL,
        .slaveListening = false,
#if FSL_FEATURE_I2C_HAS_START_STOP_DETECT
        .startStopDetect  = false,
#endif
#if FSL_FEATURE_I2C_HAS_STOP_DETECT
        .stopDetect       = false,
#endif
    };

    // Initialize slave
    I2C_DRV_SlaveInit(i2c_instance, &userConfig, &slave);

    //4d 39 68
    sendData[0]=0x4d; sendData[1]=0x39;

    // Slave receive data from HEXIWEAR I2C_DRV_SlaveReceiveDataPolling
    I2C_DRV_SlaveReceiveDataBlocking(i2c_instance, &receData, 1, 10000);
//    OSA_TimeDelay(1);
    _ASM_NOP();_ASM_NOP();_ASM_NOP();
    // Slave send temp value to HEXIWEAR I2C_DRV_SlaveSendData I2C_DRV_SlaveSendDataBlocking I2C_DRV_SlaveSendDataPolling
    i2c_user_status = I2C_DRV_SlaveSendDataBlocking(i2c_instance, sendData, 2, 10);

    I2C_DRV_SlaveDeinit(i2c_instance);
//    i2c_user_status = I2C_DRV_SlaveSendDataBlocking(i2c_instance, sendData, 2, 10100);
    if (i2c_user_status == kStatus_I2C_Success)
    {
        result = true;
    }
    kprintf("I2C SLAVE RECEIVED DATA:");
    kprintf("0x%x\n", receData);



    /* Print the slave received data */
    kprintf("I2C SLAVE SEND DATA:");

    for (uint8_t i = 0; i < I2C_HEXI_SEND_NUM; i++)
    {
        kprintf("0x%x ", sendData[i]);
    }
    kprintf("\r\n");



    return result;
}


/*!!! Not use in SDK 2.0 !!!*/

/*TASK*-------------------------------------------------------------------
*
* Task Name : i2cActAsSlaveForEx
* Comments  :
*        Assist case for i2c example
*END*----------------------------------------------------------------------*/
bool i2cActAsSlaveForEx(uint32_t i2c_instance)
{
 uint8_t count = 0;
 uint8_t *dataPtr = NULL;
 i2c_slave_state_t slave;
 i2c_slave_user_config_t userConfig =
 {
     .address        = i2c_addrs[i2c_instance],
     .slaveCallback  = NULL,
     .callbackParam  = NULL,
     .slaveListening = false,
#if FSL_FEATURE_I2C_HAS_START_STOP_DETECT
     .startStopDetect  = false,
#endif
#if FSL_FEATURE_I2C_HAS_STOP_DETECT
     .stopDetect       = false,
#endif
 };

 // Initialize slave
 I2C_DRV_SlaveInit(i2c_instance, &userConfig, &slave);

 for (uint8_t i = 0; i < I2C_EX_TEST_NUM; i++)
 {
   I2C_DRV_SlaveReceiveData(i2c_instance, (uint8_t*)&count, 1);

   /* Wait until transfer is successful */
   while (I2C_DRV_SlaveGetReceiveStatus(i2c_instance, NULL) != kStatus_I2C_Success);

   dataPtr = (uint8_t *)_mem_alloc(count * sizeof(uint8_t));

   memset(dataPtr, 0, count * sizeof(uint8_t));

   // Slave receive buffer from master
   I2C_DRV_SlaveReceiveDataBlocking(i2c_instance, dataPtr, count, 1000);

   // Slave send buffer received from master
   I2C_DRV_SlaveSendDataBlocking(i2c_instance, dataPtr, count, 1000);

   _mem_free(dataPtr);

   dataPtr = NULL;
 }
 I2C_DRV_SlaveDeinit(i2c_instance);

 return true;
}

/*TASK*-------------------------------------------------------------------
*
* Task Name : i2cActAsMasterForI2CComm
* Comments  :
*        Assist case for i2c example
*END*----------------------------------------------------------------------*/
bool i2cActAsMasterForEx(uint32_t i2c_instance)
{
 bool result = true;
 uint8_t count = 1;
 uint8_t *sendDataPtr = NULL;
 uint8_t *recvDataPtr = NULL;
 i2c_master_state_t master;

 i2c_device_t device =
 {
   .address = i2c_addrs[i2c_instance],
   .baudRate_kbps = i2c_bdrs[i2c_instance]   // Kbps
 };
 I2C_DRV_MasterInit(i2c_instance, &master);
 // data section
 sendDataPtr = (uint8_t *)_mem_alloc(I2C_EX_TEST_NUM * sizeof(uint8_t));
 recvDataPtr = (uint8_t *)_mem_alloc(I2C_EX_TEST_NUM * sizeof(uint8_t));
 // set data to 0, 1, 2, ..., count
 dataReset(sendDataPtr, I2C_EX_TEST_NUM);

 for (uint8_t i = 0; i < I2C_EX_TEST_NUM; i++)
 {
   kprintf("Master sends %d bytes:\r\n", count);
   OSA_TimeDelay(25);
   I2C_DRV_MasterSendDataBlocking(i2c_instance, &device,
                                  (const uint8_t*)&count, 1,
                                  (const uint8_t*)sendDataPtr, count,
                                  1000);

   // Delay to wait slave received data
   OSA_TimeDelay(25);
   // Clear receive data setion
   memset(recvDataPtr, 0, count * sizeof(uint8_t));

   I2C_DRV_MasterReceiveDataBlocking(i2c_instance, &device,
                                     NULL, 0,
                                     recvDataPtr, count,
                                     10000);
   OSA_TimeDelay(25);
   if (i2cCompare(sendDataPtr, recvDataPtr, count) == false)
   {
     result = false;
     i2cBuffFree(sendDataPtr, recvDataPtr);
     break;
   }
   else
   {
       count++;
   }
 }

 if (result == false)
 {
     kprintf("MASTER send and receive fail!\r\n");
 }
 else
 {
     kprintf("MASTER send and receive OK!\r\n");
 }

 i2cBuffFree(sendDataPtr, recvDataPtr);

 I2C_DRV_MasterDeinit(i2c_instance);

 return result;
}

/*TASK*-------------------------------------------------------------------
*
* Task Name : i2cActAsMasterForI2CExPolling
* Comments  :
*        Assist case for i2c example polling slave
*END*----------------------------------------------------------------------*/
bool i2cActAsMasterForExPolling(uint32_t i2c_instance)
{
    bool result = true;
 uint8_t count = 1;
 uint8_t *sendDataPtr = NULL;
 uint8_t *recvDataPtr = NULL;
 i2c_master_state_t master;

 i2c_device_t device =
 {
   .address = i2c_addrs[i2c_instance],
   .baudRate_kbps = i2c_bdrs[i2c_instance]   // Kbps
 };
 I2C_DRV_MasterInit(i2c_instance, &master);
 // data section
 sendDataPtr = (uint8_t *)_mem_alloc(I2C_EX_TEST_NUM * sizeof(uint8_t));
 recvDataPtr = (uint8_t *)_mem_alloc(I2C_EX_TEST_NUM * sizeof(uint8_t));
 // set data to 0, 1, 2, ..., count
 dataReset(sendDataPtr, I2C_EX_TEST_NUM);

 for (uint8_t i = 0; i < I2C_EX_TEST_NUM; i++)
 {
   kprintf("Master sends %d bytes:\r\n", count);
   OSA_TimeDelay(25);
   I2C_DRV_MasterSendDataBlocking(i2c_instance, &device,
                                  NULL, 0,
                                  (const uint8_t*)&count, 1,
                                  1000);

   OSA_TimeDelay(25);

   I2C_DRV_MasterSendDataBlocking(i2c_instance, &device,
                                  NULL, 0,
                                  (const uint8_t*)sendDataPtr, count,
                                  1000);
   // Delay to wait slave received data
   OSA_TimeDelay(25);
   // Clear receive data setion
   memset(recvDataPtr, 0, count * sizeof(uint8_t));

   I2C_DRV_MasterReceiveDataBlocking(i2c_instance, &device,
                                     NULL, 0,
                                     recvDataPtr, count,
                                     10000);
   OSA_TimeDelay(25);
   if (i2cCompare(sendDataPtr, recvDataPtr, count) == false)
   {
     result = false;
     i2cBuffFree(sendDataPtr, recvDataPtr);
     break;
   }
   else
   {
       count++;
   }
 }

 if (result == false)
 {
     kprintf("MASTER send and receive fail!\r\n");
 }
 else
 {
     kprintf("MASTER send and receive OK!\r\n");
 }

 i2cBuffFree(sendDataPtr, recvDataPtr);

 I2C_DRV_MasterDeinit(i2c_instance);

 return result;
}

/*TASK*-------------------------------------------------------------------
*
* Task Name : i2cActAsMasterForI2CComm
* Comments  :
*        Assist func for I2C_COMM, please learn I2C_COMM demo to help you
*        understand this func
*        Round 0: read 8 byte data from slave
*        Round 1: send data to modify slave data, then read 8 byte data
*
*END*----------------------------------------------------------------------*/
bool i2cActAsMasterForI2CComm(uint32_t i2c_instance)
{
   uint8_t i, roundCount = 0, result = true;
   uint8_t cmdBuff[1] = {0xFF};
   uint8_t sendBuff[1] = {0xFF};       // save data sent to i2c slave
   uint8_t receiveBuff[1] = {0xFF};    // save data received from i2c slave

   i2c_master_state_t master;
   i2c_status_t returnValue;

   i2c_device_t slave =
   {
       .address = 0x3A,
       .baudRate_kbps = 100
   };
   // Init I2C module
   I2C_DRV_MasterInit(i2c_instance, &master);

   for (roundCount = 0; roundCount < 2; roundCount++)
   {
       /* Only read origin data on Round 0, then we change DATA on Round 1, read it again */
       if (roundCount == 1)
       {
           cmdBuff[0] = 1;
           sendBuff[0] = 0x31;
           returnValue = I2C_DRV_MasterSendDataBlocking(
                                                        i2c_instance,
                                                        &slave,
                                                        cmdBuff,
                                                        1,
                                                        sendBuff,
                                                        sizeof(sendBuff),
                                                        500);
           if (returnValue != kStatus_I2C_Success)
           {
               result = false;
           }
       }
       /* Get data from slave buffer*/
       for (i = Subaddress_Index_0; i < Invalid_Subaddress_Index; i++)
       {
           cmdBuff[0] = i;
           returnValue = I2C_DRV_MasterReceiveDataBlocking(
                                                           i2c_instance,
                                                           &slave,
                                                           cmdBuff,
                                                           1,
                                                           receiveBuff,
                                                           sizeof(receiveBuff),
                                                           500);
           if (returnValue == kStatus_I2C_Success)
           {
               kprintf("%c", receiveBuff[0]);
           }
           else
           {
               result = false;
           }
           if (i == Subaddress_Index_7)
           {
               kprintf("\r\n");
           }
       }
   }
   I2C_DRV_MasterDeinit(i2c_instance);
   return result;
}
/*TASK*-------------------------------------------------------------------
*
* Task Name : i2cActAsSlaveForI2CComm
* Comments  :
*        Assist func for I2C_COMM, please learn I2C_COMM demo to help you
*        understand this func
*END*----------------------------------------------------------------------*/
bool i2cActAsSlaveForI2CComm(uint32_t i2c_instance)
{
   uint8_t u8SlaveDataBuffer[Max_Subaddress_Index]   = {'I', '2', 'C', '-', 'C', 'O', 'M', 'M', };
   uint8_t recvData[2] = {0}, i = 0, roundCount = 0;
   i2c_status_t returnValue;
   i2c_slave_state_t slave;
   i2c_slave_user_config_t userConfig =
   {
       .address = I2C_KSDK_SLAVE_ADDRESS,
       .slaveListening = false,
       .slaveCallback  = NULL,
       .callbackParam  = NULL,
#if FSL_FEATURE_I2C_HAS_START_STOP_DETECT
       .startStopDetect  = false,
#endif
#if FSL_FEATURE_I2C_HAS_STOP_DETECT
       .stopDetect       = false,
#endif
   };


   // Initiate I2C instance module
   I2C_DRV_SlaveInit(i2c_instance, &userConfig, &slave);
   for (roundCount = 0; roundCount < 2; roundCount++)
   {
       /* Round 0 to transfer origin data, round 1 to transfer modified data*/
       if (roundCount == 1)
       {
           returnValue = I2C_DRV_SlaveReceiveDataBlocking(i2c_instance, recvData, 2, 10000);
           if (returnValue != kStatus_I2C_Success)
           {
               kprintf("\r\nI2C_COMM RECV DATA FAILED");
               return false;
           }
           u8SlaveDataBuffer[recvData[0]] = recvData[1];
       }
       /* Ready the data which will transfer to Master*/
       for (i = 0; i < Invalid_Subaddress_Index; i++)
       {
           // Slave receive buffer from master
           returnValue = I2C_DRV_SlaveReceiveDataBlocking(i2c_instance, recvData, 1, 10000);
           if (returnValue != kStatus_I2C_Success)
           {
               kprintf("\r\nI2C_COMM RECV DATA FAILED");
               return false;
           }

           // Slave send buffer to master
           returnValue = I2C_DRV_SlaveSendDataBlocking(i2c_instance, (u8SlaveDataBuffer + recvData[0]), 1,10000);
           if (returnValue != kStatus_I2C_Success)
           {
               kprintf("\r\nI2C_COMM SEND DATA FAILED");
               return false;
           }
       }
   }
   I2C_DRV_SlaveDeinit(i2c_instance);
   return true;
}
/*TASK*-------------------------------------------------------------------
*
* Task Name : i2cActAsSlaveForI2CRtos
* Comments  :
*   Print out all LED operation, return the default ID & TEMP(24c) to the master.
*   Exit test when we read ID.
*
*END*----------------------------------------------------------------------*/
bool i2cActAsSlaveForI2CRtos(uint32_t i2c_instance)
{
   uint8_t slaveID[4]   = {0x43, 0x00, 0x02, 0x00};
   uint8_t slaveTEMP[4] = {0x18, 0, 0, 0};
   uint8_t i = 0, result = true;
   bool endFlag = false;
   i2c_status_t returnValue;
   i2c_slave_state_t slave;
   uint8_t recvCmd[2] = {0};
   uint8_t recvData[2] = {0};
   i2c_slave_user_config_t userConfig =
   {
       .address = I2C_KSDK_RTOS_SLAVE_ADDRESS,
       .slaveListening = false,
       .slaveCallback  = NULL,
       .callbackParam  = NULL,
#if FSL_FEATURE_I2C_HAS_START_STOP_DETECT
       .startStopDetect  = false,
#endif
#if FSL_FEATURE_I2C_HAS_STOP_DETECT
       .stopDetect       = false,
#endif
   };
   I2C_DRV_SlaveInit(i2c_instance, &userConfig, &slave);

   while (1)
   {
       returnValue = I2C_DRV_SlaveReceiveDataBlocking(i2c_instance, recvCmd, 2, 10000);
       if (returnValue != kStatus_I2C_Success)
       {
           kprintf("\r\nI2C_RTOS RECV DATA FAILED\r\n");
           result = false;
       }
       switch  (recvCmd[1])
       {
       case I2C_RTOS_LIGHT_CMD:
           returnValue = I2C_DRV_SlaveReceiveDataBlocking(i2c_instance, recvData, 2, 10000);
           if (returnValue != kStatus_I2C_Success)
           {
               kprintf("\r\nI2C_RTOS RECV DATA FAILED\r\n");
               result = false;
           }
           i2cRtosLedStatePrint(recvCmd, recvData);
           break;
       case I2C_RTOS_TEMP_CMD:
           returnValue = I2C_DRV_SlaveSendDataBlocking(i2c_instance, slaveTEMP, 4,10000);
           if (returnValue != kStatus_I2C_Success)
           {
               kprintf("\r\nI2C_RTOS SEND TEMP FAILED\r\n");
               result = false;
           }
           break;
       case I2C_RTOS_READID_CMD:
           returnValue = I2C_DRV_SlaveSendDataBlocking(i2c_instance, slaveID, 4,10000);
           if (returnValue != kStatus_I2C_Success)
           {
               kprintf("\r\nI2C_RTOS SEND ID FAILED\r\n");
               result = false;
           }
           endFlag = true;
           break;
       default:
           break;
       }
       if (endFlag == true) break;
   }
   returnValue = I2C_DRV_SlaveDeinit(i2c_instance);
   if (returnValue != kStatus_I2C_Success)
   {
       return false;
   }
   return result;

}
/*TASK*-------------------------------------------------------------------
*
* Task Name : i2cActAsMasterForI2CRtos
* Comments  :
*    Act as master, print out the TEMP get from i2c_rtos_slave.
*END*----------------------------------------------------------------------*/
bool i2cActAsMasterForI2CRtos(uint32_t i2c_instance)
{
   uint8_t result = true;
   i2c_status_t returnValue;
   uint8_t cmdBuff[1] = {I2C_RTOS_MAGIC};
   uint8_t sendBuff[1] = {I2C_RTOS_TEMP_CMD};       // save data sent to i2c slave
   uint8_t receiveBuff[4] = {0};    // save data received from i2c slave
   i2c_master_state_t master;
   i2c_device_t slave =
   {
       .address = I2C_KSDK_RTOS_SLAVE_ADDRESS,
       .baudRate_kbps = 100
   };
   // Init I2C module
   I2C_DRV_MasterInit(i2c_instance, &master);

   returnValue = I2C_DRV_MasterSendDataBlocking(
                                                i2c_instance,
                                                &slave,
                                                cmdBuff,
                                                1,
                                                sendBuff,
                                                sizeof(sendBuff),
                                                500);
   if (returnValue != kStatus_I2C_Success)
   {
       kprintf("\r\nI2C_RTOS SEND DATA FAILED");
       result = false;
   }
   OSA_TimeDelay(200);
   returnValue = I2C_DRV_MasterReceiveDataBlocking(
                                                   i2c_instance,
                                                   &slave,
                                                   NULL,
                                                   0,
                                                   receiveBuff,
                                                   sizeof(receiveBuff),
                                                   500);
   if (returnValue == kStatus_I2C_Success)
   {
       kprintf("\r\nK70 READ TEMP IS : %d C\r\n", receiveBuff[0]);
   }
   else
   {
       result = false;
   }
   I2C_DRV_MasterDeinit(i2c_instance);
   return result;
}
/*TASK*-------------------------------------------------------------------
*
* Task Name : i2cRtosLedStatePrint
* Comments  :
*   Print which led and the operation method.
*
*END*----------------------------------------------------------------------*/
bool i2cRtosLedStatePrint(uint8_t * recvCmd, uint8_t * recvData)
{
   switch (recvData[0])
   {
   case CMD_RED_LED:
       if (recvData[1] == I2C_RTOS_LED_ON)
       {
           kprintf("\r\nRED LED ON");
       }
       else if(recvData[1] == I2C_RTOS_LED_OFF)
       {
           kprintf("\r\nRED LED OFF");
       }
       else
       {
           return false;
       }
       break;
   case CMD_GREEN_LED:
       if (recvData[1] == I2C_RTOS_LED_ON)
       {
           kprintf("\r\nGREEN LED ON");
       }
       else if(recvData[1] == I2C_RTOS_LED_OFF)
       {
           kprintf("\r\nGREEN LED OFF");
       }
       else
       {
           return false;
       }
       break;
   case CMD_BLUE_LED:
       if (recvData[1] == I2C_RTOS_LED_ON)
       {
           kprintf("\r\nBLUE LED ON");
       }
       else if(recvData[1] == I2C_RTOS_LED_OFF)
       {
           kprintf("\r\nBLUE LED OFF");
       }
       else
       {
           return false;
       }
       break;
   default:
       break;
   }
   return true;
}
/*TASK*-------------------------------------------------------------------
*
* Task Name : dataReset
* Comments  :
*        Reset the data for I2C exmaple send buffer
*END*----------------------------------------------------------------------*/
void dataReset(uint8_t *dataPtr, uint32_t length)
{
  for (uint8_t i = 0; i < length; i++)
    dataPtr[i] = i;
}
/*TASK*-------------------------------------------------------------------
*
* Task Name : i2cBuffFree
* Comments  :
*        Free the I2C transfer Buff
*END*----------------------------------------------------------------------*/
void i2cBuffFree(uint8_t * buff1, uint8_t * buff2)
{
    _mem_free(buff1);
    _mem_free(buff2);
    buff1 = NULL;
    buff1 = NULL;
}
/*TASK*-------------------------------------------------------------------
*
* Task Name : i2cCompare
* Comments  :
*        This func compares the data received with the data send.
*END*----------------------------------------------------------------------*/
bool i2cCompare(uint8_t *data1, uint8_t *data2, uint8_t count)
{
  uint8_t i;
  /* Comapre source and sink data*/
  for (i = 0; i < count ; i++)
  {
      if (data1[i] != data2[i])
      {
          return false;
      }
  }
  return true;
}
