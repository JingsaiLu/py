#ifndef __ftm_auto_h__
#define __ftm_auto_h__
/**HEADER********************************************************************
*
* Copyright (c) 2014 Freescale Semiconductor;
* All Rights Reserved
*
***************************************************************************
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
* THE POSSIBILITY OF SUCH DAMAGE.
*
**************************************************************************
*
* $FileName: ftm_auto.h$
* $Version : $
* $Date    : May-13-2014$
*
*END************************************************************************/
#include "mqx_auxiliary_types.h"
#include "hcasf_command_type.h"
#include "stdlib.h"

#define FTM0_DEVICE                 "ftm0:"
#define PIT_CHANNEL_EDMA             0
#define PIT_CVAL_ADDR_EDMA              ((uint32_t)&PIT_CVAL_REG(PIT, PIT_CHANNEL_EDMA))
#define FTM_SAMPLE_NUM        10
//#define DEBUG_LOG_ENABLE 1

typedef struct ftm_freq_ratio
{
    uint32_t            freq;
    uint32_t            ratio;
}FTM_FREQ_RATIO,* FTM_FREQ_RATIO_PTR;

bool ftmInitFunc(uint32_t argc, uint8_t* argv[]);
bool ftmSetFreqFunc(uint32_t argc, uint8_t* argv[]);
bool ftmSetRatioFunc(uint32_t argc, uint8_t* argv[]);
bool ftmSetEdgeModeFunc(uint32_t argc, uint8_t* argv[]);
bool ftmOutputPWMEdge(uint32_t);
bool ftmOutputPWMEdge_ENC(uint32_t argc, uint8_t* argv[]);
bool ftmOutputPWMCenter(uint32_t);
bool exFTMCapture(uint32_t);
bool ftmActFunc(uint32_t argc, uint8_t* argv[]);
void ftmTerminal(void);
static void ftmSetPs(uint32_t instance);

#endif