/**HEADER********************************************************************
*
* Copyright (c) 2014 Freescale Semiconductor;
* All Rights Reserved
*
***************************************************************************
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
* THE POSSIBILITY OF SUCH DAMAGE.
*
**************************************************************************
*
* $FileName: ftm_auto.c$
* $Version : $
* $Date    : May-13-2014$
*
* Comments:
*
*   This file contains functions used in ftm autotest case.
* Comments         :
*    CMDS:  ~I<FTM><0><STATE><ON>*
*           ~I<FTM><0><STATE><OFF>*
*           ~C<FTM><0><PWM_F><*>*
*           ~C<FTM><0><PWM_RATIO><*>*
*           ~C<FTM><0><PWM_EM><LOW/HIGH>*
*           ~A<FTM><0><ACT><CAPTURE>*
*           ~A<FTM><0><ACT><O_EDGE>*
*           ~A<FTM><0><ACT><O_CENTER>*      are supported.
*
*END************************************************************************/
#include <mqx.h>
#include <bsp.h>
#include <message.h>
#include <math.h>
#include "fsl_ftm_driver.h"
#include "fsl_pit_driver.h"
#include "fsl_edma_driver.h"
#include "fsl_clock_manager.h"
#include "ftm_auto.h"
#include "tpm_auto.h"
#include "pin_mux.h"

#ifdef TWR_K65F180M
#define FTM_INST 3u
#else
#define FTM_INST 0u
#endif

#define PIT_INSTANCE_USE 0
#define TPM_CAP_DEFAULT_DELAY 10

// Variables
static bool ftm_success_flag = false;
static bool ex_ftm_capture_flag = false;
static volatile uint32_t ftm_cap_count = 0;

static ftm_pwm_param_t s_pwm_param[FTM_INSTANCE_COUNT];
static bool ftm_init[FTM_INSTANCE_COUNT] = {false};
static bool edma_transfer_done[FSL_FEATURE_EDMA_MODULE_CHANNEL] = {false};
static uint32_t time_stamp_rising[FTM_SAMPLE_NUM];
static uint32_t time_stamp_falling[FTM_SAMPLE_NUM];

static edma_chn_state_t *chnStateRising = NULL;
static edma_chn_state_t *chnStateFalling = NULL;

static uint32_t current_ftm_inst = 0;

// Function
void startFTMCapture(uint32_t, uint32_t, ftm_input_capture_edge_mode_t);

// Help function
void getFreqFromPeriod(uint32_t *, uint32_t);
void getPeriodFromFreq(uint32_t *, uint32_t);
uint32_t getVariance(uint32_t *, uint32_t, uint32_t *);
uint32_t getMean(uint32_t *, uint32_t);
uint32_t getResultMean(uint32_t *, uint32_t);
float getReliability(uint32_t *, uint32_t);

/*FUNCTION****************************************************************
*
* Function Name    : ftm_auto_init
* Returned Value   : false/ true
* Comments         :
*    CMDS:  ~I<FTM><0><STATE><ON>*
*           ~I<FTM><0><STATE><OFF>*
*           ~C<FTM><0><PWM_F><*>*
*           ~C<FTM><0><PWM_RATIO><*>*
*           ~C<FTM><0><PWM_EM><LOW/HIGH>*    are supported.
*
*    function need update.
*END*********************************************************************/

bool ftmInitFunc(uint32_t argc, uint8_t* argv[])
{
    /*Use channel 0 as default instance, need update more*/

    if (2 > argc || NULL == argv[0] || NULL == argv[1])
    {
        return false;
    }

    uint32_t instance = *argv[0] - '0';

    if (instance >= FTM_INSTANCE_COUNT)
    {
      return false;
    }
    /* init ftm */
    if (0 == strcmp((char const *)argv[1], "ON"))
    {
      configure_ftm_pins(instance);
      ftm_user_config_t ftmInfo;
      memset(&ftmInfo, 0, sizeof(ftmInfo));
      ftmInfo.syncMethod = kFtmUseSoftwareTrig;
      FTM_DRV_Init(instance, &ftmInfo);
      FTM_DRV_SetClock(instance, kClock_source_FTM_SystemClk, kFtmDividedBy1);
      /* init pwm param structure */
      memset(&s_pwm_param[instance], 0, sizeof(s_pwm_param[instance]));
      ftm_init[instance] = true;
      PIT_DRV_Init(PIT_INSTANCE_USE, false);
      return true;
    }
    /* deinit ftm */
    else if (0 == strcmp((char const *)argv[1], "OFF"))
    {
        //if (ftm_success_flag == 1)
        //{
          /* disable */
          FTM_DRV_Deinit(instance);
          configure_ftm_pins(instance);
          ftm_init[instance] = false;

          PIT_DRV_Deinit(PIT_INSTANCE_USE);
        //}
    }
    else /* wrong param */
    {
        return false;
    }
    return true;
}

bool ftmSetFreqFunc(uint32_t argc, uint8_t* argv[])
{
    uint32_t freq_param = 0;

    /*use channel 0 as default instance, need update more*/

    if (2 > argc || NULL == argv[0] || NULL == argv[1])
    {
        return false;
    }

    uint32_t instance = *argv[0] - '0';

    if (instance >= FTM_INSTANCE_COUNT)
    {
      return false;
    }

    if (false == ftm_init[instance])
      return false;

    freq_param = hcasf_string2uint32(argv[1]);

    s_pwm_param[instance].uFrequencyHZ = freq_param;

    return true;
}

bool ftmSetRatioFunc(uint32_t argc, uint8_t* argv[])
{
    uint8_t duty_ratio = 0;

    /*Use channel 0 as default instance, need update more*/

    if (2 > argc || NULL == argv[0] || NULL == argv[1])
    {
        return false;
    }

    uint32_t instance = *argv[0] - '0';

    if (instance >= FTM_INSTANCE_COUNT)
    {
      return false;
    }

    if (false == ftm_init[instance])
      return false;

    duty_ratio = (uint8_t)hcasf_string2uint32(argv[1]);
    if (duty_ratio < 0 || duty_ratio > 100)
      return false;
    s_pwm_param[instance].uDutyCyclePercent = duty_ratio;

    return true;
}

bool ftmSetEdgeModeFunc(uint32_t argc, uint8_t* argv[])
{
    /*Use channel 0 as default instance, need update more*/

    if (2 > argc || NULL == argv[0] || NULL == argv[1])
    {
        return false;
    }

    uint32_t instance = *argv[0] - '0';

    if (instance >= FTM_INSTANCE_COUNT)
    {
      return false;
    }

    if (false == ftm_init[instance])
      return false;

    if(strcmp((char const *)argv[1], "HIGH") == 0)
    {
      s_pwm_param[instance].edgeMode = kFtmHighTrue;
    }
    else if(strcmp((char const *)argv[1], "LOW") == 0)
    {
      s_pwm_param[instance].edgeMode = kFtmLowTrue;
    }
    else /* wrong param */
    {
      return false;
    }
    return true;
}

/* output edge aligned pwm */
bool ftmOutputPWMEdge(uint32_t instance)
{
  s_pwm_param[instance].mode = kFtmEdgeAlignedPWM;
  FTM_HAL_SetCounterInitVal(g_ftmBase[instance], 0);
  FTM_HAL_SetSoftwareTriggerCmd(g_ftmBase[instance], true);
  FTM_DRV_PwmStart(instance, &s_pwm_param[instance], 0);

  return true;
}

bool ftmOutputPWMCenter(uint32_t instance)
{
  s_pwm_param[instance].mode = kFtmCenterAlignedPWM;
  FTM_HAL_SetCounterInitVal(g_ftmBase[instance], 0);
  FTM_HAL_SetSoftwareTriggerCmd(g_ftmBase[instance], true);
  FTM_DRV_PwmStart(instance, &s_pwm_param[instance], 0);

  return true;
}

void startFTMCapture(uint32_t instance, uint32_t channel, ftm_input_capture_edge_mode_t mode)
{
  FTM_HAL_SetChnDmaCmd(g_ftmBase[instance], channel, true);
  FTM_DRV_SetupChnInputCapture(instance, mode, channel, 0);
  FTM_HAL_EnableChnInt(g_ftmBase[instance], channel);
}

void stopFTMCapture(uint32_t instance, uint32_t channel)
{
  FTM_HAL_DisableChnInt(g_ftmBase[instance], channel);
  FTM_HAL_SetChnDmaCmd(g_ftmBase[instance], channel, false);
}

bool getValidEDMA(edma_chn_state_t *chnState, dma_request_source_t source, uint32_t srcAddr, uint32_t dstAddr)
{
  // EDMA channel request.
  if (kEDMAInvalidChannel == EDMA_DRV_RequestChannel(kEDMAAnyChannel,
                                                     source,
                                                     chnState))
  {
    return false;
  }
  // Prepare memory pointing to software TCDs.
  edma_status_t result;
  edma_software_tcd_t *stcd = (edma_software_tcd_t *)_mem_alloc(4*sizeof(edma_software_tcd_t));
  result = EDMA_DRV_ConfigLoopTransfer(chnState,
                                       stcd,
                                       kEDMAPeripheralToMemory,
                                       srcAddr,
                                       dstAddr,
                                       4,
                                       4,
                                       FTM_SAMPLE_NUM * 4, 1);
  _mem_free(stcd);
  stcd = NULL;
  if (kStatus_EDMA_Success != result)
  {
    return false;
  }
  return true;
}

/* using flag to indicate edma transfer status */
void edmaCallback(void *param, edma_chn_status_t status)
{
  edma_chn_state_t *ptr = (edma_chn_state_t *)param;
  edma_transfer_done[ptr->channel] = true;
}

/* Must call captureUseEDMA() first to get data */
bool getFreq(uint32_t *freq_ptr)
{
  /* skip several intervals for they are not reliable. */
  uint8_t    offset_start = 2;
  uint32_t   interval_size = FTM_SAMPLE_NUM-offset_start-1;
  /* Laphael Dong says we should use heap as many as possible, let him happy. */
  uint32_t   *freq_falling = (uint32_t *)_mem_alloc((interval_size)*sizeof(uint32_t));
  uint32_t   *freq_rising = (uint32_t *)_mem_alloc((interval_size)*sizeof(uint32_t));

  memset(freq_falling, 0, (interval_size)*sizeof(uint32_t));
  memset(freq_rising, 0, (interval_size)*sizeof(uint32_t));

  /* get time interval */
  for (uint32_t i = 0; i < interval_size; i++)
  {
    freq_falling[i] = time_stamp_falling[i+offset_start]-time_stamp_falling[i+offset_start+1];
    freq_rising[i] = time_stamp_rising[i+offset_start]-time_stamp_rising[i+offset_start+1];
  }

  /* get frequency in hz */
  getFreqFromPeriod(freq_falling, interval_size);
  getFreqFromPeriod(freq_rising, interval_size);

  /* get coefficient of variance */
  /* ref: http://baike.baidu.com/view/108059.htm */
  float  cv_falling = 0.0, cv_rising = 0.0;

  cv_falling = getReliability(freq_falling, interval_size);
  cv_rising = getReliability(freq_rising, interval_size);

  if (cv_falling > 0.5 || cv_rising > 0.5)
  {
    /* ONLY FOR DEBUG */
#if DEBUG_LOG_ENABLE
    for (uint32_t i = 0; i < interval_size; i++)
    {
      kprintf("freq_falling[%d] = %d\r\n", i, freq_falling[i]);
      kprintf("freq_rising[%d] = %d\r\n", i, freq_rising[i]);
    }
    kprintf("falling reliability = %d\r\n", 100*cv_falling);
    kprintf("rising reliability = %d\r\n", 100*cv_rising);
#endif
    _mem_free(freq_falling);
    _mem_free(freq_rising);
    freq_falling = NULL;
    freq_rising = NULL;
    return false;
  }

  uint32_t a = getResultMean(freq_falling, interval_size);
  uint32_t b = getResultMean(freq_falling, interval_size);

  *freq_ptr = (uint32_t)(a + b)/2;

  _mem_free(freq_falling);
  _mem_free(freq_rising);
  freq_falling = NULL;
  freq_rising = NULL;

  return true;
}

/* Must call captureUseEDMA() first to get data */
bool getRatio(uint32_t *ratio_ptr)
{
  /* skip several intervals for they are not reliable. */
  uint32_t   *high_lvl_time = (uint32_t *)_mem_alloc((FTM_SAMPLE_NUM)*sizeof(uint32_t));
  uint32_t   *low_lvl_time = (uint32_t *)_mem_alloc((FTM_SAMPLE_NUM)*sizeof(uint32_t));
  uint32_t   offset_start = 2;
  uint32_t   valid_high_count = 0;
  uint32_t   valid_low_count = 0;
  uint32_t   cur_inner_start = 0;
  uint32_t   interval_size = FTM_SAMPLE_NUM-offset_start-1;

  /* calculate high and low level time series */
  for (uint32_t i = 0; i < interval_size; i++)
  {
    /* find first time_stamp_falling[j] < time_stamp_rising[i]
       and time_stamp_falling[j] > time_stamp_rising[i+1]
    */
    for (uint32_t j = cur_inner_start; j < interval_size; j++)
    {
      if (time_stamp_rising[i+offset_start] > time_stamp_falling[j+offset_start] &&
          time_stamp_rising[i+offset_start+1] < time_stamp_falling[j+offset_start])
      {
        high_lvl_time[valid_high_count++] = time_stamp_rising[i+offset_start] - time_stamp_falling[j+offset_start];
        low_lvl_time[valid_low_count++] = time_stamp_falling[j+offset_start] - time_stamp_rising[i+offset_start+1];
        cur_inner_start = j + 1;
        break;
      }
      if (cur_inner_start == interval_size)
        break;
    }
  }


  /* get coefficient of variance */
  /* ref: http://baike.baidu.com/view/108059.htm */
  float  cv_high = 0.0, cv_low = 0.0;

  cv_high = getReliability(high_lvl_time, valid_high_count);
  cv_low = getReliability(low_lvl_time, valid_low_count);

  if (cv_high > 0.5 || cv_low > 0.5)
  {
    /* ONLY FOR DEBUG */
#if DEBUG_LOG_ENABLE
    for (uint32_t i = 0; i < valid_high_count; i++)
    {
      kprintf("high_lvl_time[%d] = %d\r\n", i, high_lvl_time[i]);
    }
    kprintf("\r\n");
    for (uint32_t i = 0; i < valid_low_count; i++)
    {
      kprintf("low_lvl_time[%d] = %d\r\n", i, low_lvl_time[i]);
    }
    kprintf("high reliability = %d\r\n", 100*cv_high);
    kprintf("low reliability = %d\r\n", 100*cv_low);
#endif
    _mem_free(high_lvl_time);
    _mem_free(low_lvl_time);
    return false;
  }

  uint32_t high = getResultMean(high_lvl_time, valid_high_count);
  uint32_t low = getResultMean(low_lvl_time, valid_low_count);

  /* 0xfffffff / 100 =  2684354 = 0x28f5c2 */
  if(high > 2684354 )
  {
    high = high >> 7;
    low = low >> 7;
  }

    *ratio_ptr = 100 * high / (high + low);

  _mem_free(high_lvl_time);
  _mem_free(low_lvl_time);
  high_lvl_time = NULL;
  low_lvl_time = NULL;

  return true;
}

/* Use FTM to trigger EDMA and capture PIT counter register */
bool captureUseEDMA(uint32_t ftm_instance)
{
  /* Init eDMA modules. */
  edma_state_t         edmaState;
  edma_user_config_t   edmaUserConfig;
  int cnt = 350;
  current_ftm_inst = ftm_instance;
  edmaUserConfig.chnArbitration = kEDMAChnArbitrationFixedPriority;
  edmaUserConfig.notHaltOnError = false;
  EDMA_DRV_Init(&edmaState, &edmaUserConfig);

  /* Request eDMA channel */
  chnStateRising = (edma_chn_state_t *)_mem_alloc(sizeof(edma_chn_state_t));
  chnStateFalling = (edma_chn_state_t *)_mem_alloc(sizeof(edma_chn_state_t));

  bool res1, res2;
  res1 = getValidEDMA(chnStateRising,  kDmaRequestMux0FTM0Channel0,
                      PIT_CVAL_ADDR_EDMA, (uint32_t)time_stamp_rising);
  res2 = getValidEDMA(chnStateFalling, kDmaRequestMux0FTM0Channel1,
                      PIT_CVAL_ADDR_EDMA, (uint32_t)time_stamp_falling);

  /* no valid edma channel */
  if (!res1 || !res2)
  {
    _mem_free(chnStateRising);
    _mem_free(chnStateFalling);
    EDMA_DRV_Deinit();
    return false;
  }
  /* reset data section */
  memset(time_stamp_rising, 0, FTM_SAMPLE_NUM * sizeof(uint32_t));
  memset(time_stamp_falling, 0, FTM_SAMPLE_NUM * sizeof(uint32_t));
  memset(edma_transfer_done, 0, FSL_FEATURE_EDMA_MODULE_CHANNEL * sizeof(bool));

  /* start edma channel */
  EDMA_DRV_InstallCallback(chnStateRising, edmaCallback, chnStateRising);
  EDMA_DRV_InstallCallback(chnStateFalling, edmaCallback, chnStateFalling);
  /* only use edma for once */
  EDMA_HAL_HTCDSetDisableDmaRequestAfterTCDDoneCmd(DMA0, chnStateRising->channel, true);
  EDMA_HAL_HTCDSetDisableDmaRequestAfterTCDDoneCmd(DMA0, chnStateFalling->channel, true);
  /* First start channel waiting for FTM interrupt signal */
  EDMA_DRV_StartChannel(chnStateRising);
  EDMA_DRV_StartChannel(chnStateFalling);

  /* Second init FTM and enable its capture and interrupt */
  startFTMCapture(ftm_instance, 0, kFtmRisingEdge);
  startFTMCapture(ftm_instance, 1, kFtmFallingEdge);

  /* wait until edma transfer is done */
  while ((!edma_transfer_done[chnStateRising->channel] ||
         !edma_transfer_done[chnStateFalling->channel])&& cnt)
  {
    /*only wait for 1s for the signal to come*/
    cnt--;
    OSA_TimeDelay(100);
  }

  /* stop capture and disable interrupt */
  stopFTMCapture(ftm_instance, 0);
  stopFTMCapture(ftm_instance, 1);

  /* deinit edma */
  EDMA_DRV_StopChannel(chnStateRising);
  EDMA_DRV_StopChannel(chnStateFalling);
  EDMA_DRV_ReleaseChannel(chnStateRising);
  EDMA_DRV_ReleaseChannel(chnStateFalling);
  EDMA_DRV_Deinit();

  _mem_free(chnStateRising);
  _mem_free(chnStateFalling);
  chnStateRising = NULL;
  chnStateFalling = NULL;

  return true;
}

void ftmTerminal(void)
{
    /* stop capture and disable interrupt */
  stopFTMCapture(current_ftm_inst, 0);
  stopFTMCapture(current_ftm_inst, 1);

  /* deinit edma */
  EDMA_DRV_StopChannel(chnStateRising);
  EDMA_DRV_StopChannel(chnStateFalling);
  EDMA_DRV_ReleaseChannel(chnStateRising);
  EDMA_DRV_ReleaseChannel(chnStateFalling);
  EDMA_DRV_Deinit();

  if (chnStateRising != NULL )
  {
     _mem_free(chnStateRising);
     chnStateRising = NULL;
  }
  if (chnStateFalling != NULL)
  {
    _mem_free(chnStateFalling);
    chnStateFalling = NULL;
  }
}

/* A full capture process. Data is stored in freq_ptr and ratio_ptr */
bool ftmCaptureOnce(uint32_t ftm_instance, uint32_t *freq_ptr, uint32_t *ratio_ptr)
{
  /* start PIT */
  pit_user_config_t chnConfg = {
      .isInterruptEnabled = true,
      .periodUs = 0xffffffff
  };
  PIT_DRV_InitChannel(PIT_INSTANCE_USE, PIT_CHANNEL_EDMA, &chnConfg);
  PIT_DRV_StartTimer(PIT_INSTANCE_USE, PIT_CHANNEL_EDMA);

  /* configure edma and capture once */
  if (captureUseEDMA(ftm_instance) == false)
  {
    return false;
  }
  /* stop PIT */
  PIT_DRV_StopTimer(PIT_INSTANCE_USE, PIT_CHANNEL_EDMA);

  /* calculation of freq and ratio */
  if (false == getFreq(freq_ptr))
    return false;
  if (false == getRatio(ratio_ptr))
    return false;

  return true;
}

/* Several capture process. Each data[i] is stored in freq[i] and ratio[i] */
void ftmCaptureMultiple(uint32_t instance, uint32_t *freq, uint32_t *ratio, uint32_t times)
{
  /* capture several times*/
  for (uint32_t i = 0; i < times; i++)
  {
    if (false == ftmCaptureOnce(instance, &freq[i], &ratio[i]))
      ftmCaptureOnce(instance, &freq[i], &ratio[i]);
    _time_delay_ticks(TPM_CAP_DEFAULT_DELAY);
  }
}

bool exFTMCapture(uint32_t instance)
{
  bool res = false;
  uint32_t cnt = 0;
  uint32_t freq = 0, ratio = 0;
  /* capture 5 times */
  while (res == false && cnt < 5)
  {
    cnt++;
    res = ftmCaptureOnce(instance, &freq, &ratio);
  }
  if (res == true)
  {
    kprintf("FREQ:%d (Hz/10)\r\n",  freq);
    kprintf("RATIO:%d\r\n", ratio);
  }
  else
  {
    kprintf("CAPTURE FAIL\r\n");
  }
  /* Make sure the print info output normally*/
  OSA_TimeDelay(100);
  /*force to reset after measurement*/
   NVIC_SystemReset();
  return res;
}

bool ftmActFunc(uint32_t argc, uint8_t* argv[])
{
    uint8_t result = 0, ftm_counter = 0;
    FTM_FREQ_RATIO param;
    FTM_FREQ_RATIO_PTR param_ptr = &param;
    FTM_FREQ_RATIO ftm_result[FTM_SAMPLE_NUM] = {0};

    /*Use channel 0 as default instance, need update more*/

    if (2 > argc || NULL == argv[0] || NULL == argv[1])
    {
        return false;
    }

    uint32_t instance = *argv[0] - '0';

    if (instance >= FTM_INSTANCE_COUNT)
    {
      return false;
    }

    if (false == ftm_init[instance])
      return false;

    if (strcmp((char const *)argv[1],"O_EDGE") == 0)
    {
      ftmSetPs(instance);
      result = ftmOutputPWMEdge(instance);
      if (!result)
      {
        return false;
      }
    }
    else if (strcmp((char const *)argv[1],"O_CENTER") == 0)
    {
      ftmSetPs(instance);
      result = ftmOutputPWMCenter(instance);
      if (!result)
      {
        return false;
      }
    }
    else if(strcmp((char const *)argv[1], "CAPTURE") == 0 ||
            strcmp((char const *)argv[1], "CAP_FIX_RATIO") == 0 ||
            strcmp((char const *)argv[1], "EX_FTM_CAPTURE") == 0)
    {
      result = exFTMCapture(instance);
      return result;
    }
    else if(strcmp((char const *)argv[1], "TPM_CAPTURE") == 0)
    {
      /* tpm demo is deprecated */
    }
    else if(strcmp((char const *)argv[1], "EX_TPM_CAPTURE") == 0)
    {
      result = exFTMCapture(instance);
      return result;
    }
    else
    {
      return false;
    }
    return true;
}

#if (FSL_FEATURE_SOC_FTM_COUNT > 0U)
void FTM0_IRQHandler(void)
{
    /* Clear interrupt flag.*/
    FTM_DRV_IRQHandler(0);
}
#endif

#if (FSL_FEATURE_SOC_FTM_COUNT > 1U)
void FTM1_IRQHandler(void)
{
    /* Clear interrupt flag.*/
    FTM_DRV_IRQHandler(1);
}
#endif

#if (FSL_FEATURE_SOC_FTM_COUNT > 2U)
void FTM2_IRQHandler(void)
{
    /* Clear interrupt flag.*/
    FTM_DRV_IRQHandler(2);
}
#endif

#if (FSL_FEATURE_SOC_FTM_COUNT > 3U)
void FTM3_IRQHandler(void)
{
    /* Clear interrupt flag.*/
    FTM_DRV_IRQHandler(3);
}
#endif

/********************************************************
*                    HELP FUNCTION                      *
*********************************************************/
uint32_t getMean(uint32_t *data, uint32_t length)
{
  long mean = 0;
  /* get mean value */
  for (uint32_t i = 0; i < length; i++)
  {
    mean += data[i] / 10;
  }
  mean /= length;
  return (uint32_t)mean;
}

uint32_t getResultMean(uint32_t *data, uint32_t length)
{
  long mean = 0;
  /* get mean value */
  for (uint32_t i = 0; i < length; i++)
  {
    mean += data[i];
  }
  mean /= length;
  return (uint32_t)mean;
}


uint32_t getVariance(uint32_t *data, uint32_t length, uint32_t *mean)
{
  long variance = 0;
  float *diffs = (float *)_mem_alloc(length * sizeof(float));

  /* get difference to mean */
  for (uint32_t i = 0; i < length; i++)
  {
    diffs[i] = fabs((float)(data[i]/10 - *mean));
  }
  /* variance */
  for (uint32_t i = 0; i < length; i++)
  {
    variance += (uint32_t)pow(diffs[i], 2);
  }
  variance /= (length-1);

  _mem_free(diffs);
  diffs = NULL;

  return (uint32_t)variance;
}

float getReliability(uint32_t *data, uint32_t length)
{
  uint32_t *mean = (uint32_t *)_mem_alloc(sizeof(uint32_t));
  uint32_t *variance = (uint32_t *)_mem_alloc(sizeof(uint32_t));
  float returnVal = 0.0;

  *mean = getMean(data, length);
  *variance = getVariance(data, length, mean);

  returnVal = sqrt(*variance) / *mean;

  _mem_free(mean);
  _mem_free(variance);
  mean = NULL;
  variance = NULL;

  return returnVal;
}

/* unit of return value is Hz */
void getFreqFromPeriod(uint32_t *freq, uint32_t len)
{
  uint32_t bus_clock = CLOCK_SYS_GetBusClockFreq();
  uint32_t i = 0;
  for (i = 0; i < len; i++)
  {
    uint64_t temp = freq[i];
    /* Multiply 100 for the freq to capture the freq less than 1 Hz*/
    temp = 10 * bus_clock/temp;
    freq[i] = (uint32_t) temp ;
  }
}

/* unit of return value is us */
void getPeriodFromFreq(uint32_t *period, uint32_t len)
{
  uint32_t bus_clock = CLOCK_SYS_GetBusClockFreq();
  uint32_t i = 0;
  for (i = 0; i < len; i++)
  {
    uint64_t temp = period[i];
    temp = temp * 1000000 / bus_clock;
    period[i] = (uint32_t) temp;
  }
}

/* set FTM clock division factor according to frequncy */
static void ftmSetPs(uint32_t instance)
{
    /*set ps */
    uint32_t ftmFreq = s_pwm_param[instance].uFrequencyHZ;
    uint32_t ftmClock = FTM_DRV_GetClock(instance);
    ftm_clock_ps_t ftmPs = kFtmDividedBy1;


    if((ftmClock/(ftmFreq*128)) < 0xFFFFU)
    {
        ftmPs = kFtmDividedBy128;
        if((ftmClock/(ftmFreq*64)) < 0xFFFFU)
        {
            ftmPs = kFtmDividedBy64;
            if((ftmClock/(ftmFreq*32)) < 0xFFFFU)
            {
                ftmPs = kFtmDividedBy32;
                if((ftmClock/(ftmFreq*16)) < 0xFFFFU)
                {
                    ftmPs = kFtmDividedBy16;
                    if((ftmClock/(ftmFreq*8)) < 0xFFFFU)
                    {
                        ftmPs = kFtmDividedBy8;
                        if((ftmClock/(ftmFreq*4)) < 0xFFFFU)
                        {
                            ftmPs = kFtmDividedBy4;
                            if((ftmClock/(ftmFreq*2)) < 0xFFFFU)
                            {
                                ftmPs = kFtmDividedBy2;
                                if((ftmClock/(ftmFreq*1)) < 0xFFFFU)
                                {
                                    ftmPs = kFtmDividedBy1;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    else
    {
        ftmPs = kFtmDividedBy1;
    }

    FTM_HAL_SetClockPs(g_ftmBase[instance], ftmPs);
}
