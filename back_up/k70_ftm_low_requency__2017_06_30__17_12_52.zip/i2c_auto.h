/**HEADER********************************************************************
*
* Copyright (c) 2014 Freescale Semiconductor;
* All Rights Reserved
*
***************************************************************************
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
* THE POSSIBILITY OF SUCH DAMAGE.
*
**************************************************************************
*
* $FileName: i2c_autocase_init.c$
* $Version : $
* $Date    : February-11-2014$
* $Updated : Sep-4-2014$
* $Updated : May-20-2015$
*
* Comments:
*
*END************************************************************************/
#ifndef __i2c_auto_h__
#define __i2c_auto_h__

#include "mqx_auxiliary_types.h"

/* Global settings */
#define I2C_INTERRUPT_MODE   1
#define I2C_MEM_SIZE      0x0100   /* Overall memory byte size */
#define I2C_KSDK_SLAVE_ADDRESS 0x3a
#define I2C_KSDK_RTOS_SLAVE_ADDRESS 0x7f
#define I2C_EX_MASTER_ADDRESS  0x7f
#define I2C_EX_SLAVE_ADDRESS  0x7f
#define I2C_EX_TEST_NUM  64     /* transfer cycle number, this value MUST be smaller than 256 */
#define I2C_EX_B2B_NUM  32

#define I2C_HEXI_RECE_NUM  1
#define I2C_HEXI_SEND_NUM  2

#define I2C_RTOS_LIGHT_CMD   1
#define I2C_RTOS_TEMP_CMD    2
#define I2C_RTOS_SLEEP_CMD   3
#define I2C_RTOS_READID_CMD  4
#define I2C_RTOS_MAGIC       0xBB
#define CMD_RED_LED          0x52
#define CMD_GREEN_LED        0x47
#define CMD_BLUE_LED         0x42
#define I2C_RTOS_LED_ON      1
#define I2C_RTOS_LED_OFF     0

typedef struct
{
    uint8_t  subAddress;
    uint8_t  data;
    uint8_t  state;
} i2cData_t;

/* APIs for initial code */
bool i2cInitFunc(uint32_t, uint8_t* []);
bool i2cSetBaudrate(uint32_t, uint8_t* []);
bool i2cSetAddress(uint32_t, uint8_t* []);
bool i2cActEntry(uint32_t, uint8_t* []);
/* APIs for example code */
bool i2cActAsSlaveForB2B(uint8_t);
bool i2cActAsMasterForB2B(uint8_t);
bool i2cActAsSlaveForEx(uint32_t);
bool i2cActAsMasterForEx(uint32_t);
bool i2cActAsMasterForExPolling(uint32_t);
/* APIs for demo code */
bool i2cActAsMasterForI2CComm(uint32_t);
bool i2cActAsSlaveForI2CComm(uint32_t);
bool i2cActAsSlaveForI2CRtos(uint32_t);
bool i2cActAsMasterForI2CRtos(uint32_t);
bool i2cActAsSlaveForHEXI(uint8_t i2c_instance);

#endif